﻿using EmployeeManagments.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;


namespace EmployeeManagments.Controllers
{
    public class EmployeeController : Controller
    {
        public ActionResult Index()
        {
            string sql = @"SELECT EmpID, FirstName, LastName, Gender, City " + "FROM EmpTb";
            string strConnString = " Data Source = shivraj; Initial Catalog = Employee; Integrated Security = True; Trusted_connection=true";
            SqlConnection connection = new SqlConnection(strConnString);
            connection.Open();
            SqlDataAdapter da = new SqlDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            da.Fill(ds);
            connection.Close();
            List<Employee> lstEmp = new List<Employee>();
            Employee emp;

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                emp = new Employee();
                emp.EmpID = Convert.ToInt32(dr["EmpID"]);
                emp.FirstName = Convert.ToString(dr["FirstName"]);
                emp.LastName = Convert.ToString(dr["LastName"]);
                emp.Gender = Convert.ToString(dr["Gender"]);
                emp.City = Convert.ToString(dr["City"]);
                lstEmp.Add(emp);
            }
            return View(lstEmp);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Employee emp)
        {
            string strInsert = @"INSERT INTO EmpTb(EmpID, FirstName, LastName, Gender, City)" +
                                "VALUES(" + emp.EmpID + ", '" + emp.FirstName + "', '" + emp.LastName + "','" + emp.Gender + "','" + emp.City + "')";
            string strConnString = " Data Source = shivraj; Initial Catalog = Employee; Integrated Security = True; Trusted_connection=true";
            SqlConnection conn = new(strConnString);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = strInsert;
            cmd.CommandType = CommandType.Text;

            int n = cmd.ExecuteNonQuery();
            conn.Close();
            return RedirectToAction("index");
        }

        [HttpGet]
        public IActionResult Edit( int id )
        {
            string sql = "SELECT EmpID, FirstName, LastName, Gender, City FROM EmpTb WHERE EmpID = " + id;
            string strConnString = " Data Source = shivraj; Initial Catalog = Employee; Integrated Security = True; Trusted_connection=true";
            SqlConnection connection = new SqlConnection(strConnString);
            connection.Open();
            SqlDataAdapter da = new SqlDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            da.Fill(ds);
            connection.Close();

            if (ds != null && ds.Tables.Count > 0)
            {
                Employee emp = new Employee();
                emp.EmpID = Convert.ToInt32(ds.Tables[0].Rows[0]["EmpID"]);
                emp.FirstName = Convert.ToString(ds.Tables[0].Rows[0]["FirstName"]);
                emp.LastName = Convert.ToString(ds.Tables[0].Rows[0]["LastName"]);
                emp.Gender = Convert.ToString(ds.Tables[0].Rows[0]["Gender"]);
                emp.City = Convert.ToString(ds.Tables[0].Rows[0]["City"]);
                return View(emp);
            }
            return View();
        }

        [HttpPost]
        public IActionResult Edit(Employee emp)
        {
            string sql = "UPDATE EmpTb SET FirstName = '" + emp.FirstName + "', LastName = '" + emp.LastName + "', Gender = '" + emp.Gender + "', City = '" + emp.City + "' WHERE EmpID = " + emp.EmpID;

            string strConnString = " Data Source = shivraj; Initial Catalog = Employee; Integrated Security = True; Trusted_connection=true";

            SqlConnection conn = new SqlConnection(strConnString);
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            conn.Open();
            int n = cmd.ExecuteNonQuery();
            conn.Close();
            return RedirectToAction("index");
        }
        public IActionResult Delete(int Id)
        {
            string sql = "DELETE FROM EmpTb WHERE EmpID = " + Id;

            string strConnString = " Data Source = shivraj; Initial Catalog = Employee; Integrated Security = True; Trusted_connection=true";

            SqlConnection conn = new SqlConnection(strConnString);
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            conn.Open();
            int n = cmd.ExecuteNonQuery();
            conn.Close();
            return RedirectToAction("index");
        }
    }
}









